import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteCustomerAccount extends Frame 
{
	Button deleteCustomerButton;
	List CustomerIDList;
	TextField sinceText,cidtext,aidtext;
	//Choice cidSelect, aidSelect;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteCustomerAccount() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hema","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadLogin() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM login ");
		  while (rs.next()) 
		  {
			  CustomerIDList.add(rs.getString("Customer id"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	
	public void buildGUI() 
	{		
	    CustomerIDList = new List(10);
		loadLogin();
		//loadAccount();
		add(CustomerIDList);
		
		//When a list item is selected populate the text fields
		CustomerIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM customer_account");
					while (rs.next()) 
					{
						if (rs.getString("AccountID").equals(CustomerIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						aidtext.setText(rs.getString("AccountID"));
						cidtext.setText(rs.getString("AccountTYpe"));
						sinceText.setText(rs.getString("Balance"));
						//balancetypeText.setText(rs.getString("Balance Type"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		deleteCustomerButton = new Button("Delete Customer_Acccount");
		deleteCustomerButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM customer_account WHERE cID = "
							+ CustomerIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					cidtext.setText(null);
					aidtext.setText(null);
					//balanceText.setText(null);
					//balancetypeText.setText(null);
					AccountIDList.removeAll();
					loadLogin();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		aidtext = new TextField(15);
		cidtext = new TextField(15);
		sinceText = new TextField(15);
	//balancetypeText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Account ID:"));
		first.add(aidtext);
		first.add(new Label("Customer ID:"));
		first.add(cidtext);
		first.add(new Label("Since:"));
		first.add(sinceText);
		//first.add(new Label("Balance TYpe:"));
		//first.add(balancetypeText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteCustomerButton);
		
		Panel third = new Panel();
		third.add(errorText);
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove Account");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteAccount dels = new DeleteAccount();

		dels.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		dels.buildGUI();
	}
}
