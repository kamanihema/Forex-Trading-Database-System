import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteTrade extends Frame 
{
	Button deleteTradeButton;
	List TradeIDList;
	TextField tridText, administratorText, contactText, currencytoText,addressText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteTrade() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hema","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadTrade() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Trade");
		  while (rs.next()) 
		  {
			TradeIDList.add(rs.getString("Trade id"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    TradeIDList = new List(10);
		loadTrade();
		add(TradeIDList);
		
		//When a list item is selected populate the text fields
		TradeIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Trade");
					while (rs.next()) 
					{
						if (rs.getString("Tarde ID").equals(TradeIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						tridText.setText(rs.getString("Trade ID"));
						administratorText.setText(rs.getString("Adminstartor"));
						contactText.setText(rs.getString("Contact"));
						currencytoText.setText(rs.getString(" currency to"));
						addressText.setText(rs.getString("address"));
					
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		deleteTradeButton = new Button("Delete trade");
		deleteTradeButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM trade WHERE trid = "
							+ TradeIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					tridText.setText(null);
					administratorText.setText(null);
					contactText.setText(null);
					currencytoText.setText(null);
					addressText.setText(null);
					TradeIDList.removeAll();
					loadTrade();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		tridText = new TextField(15);
		administratorText = new TextField(15);
		contactText = new TextField(15);
	currencytoText = new TextField(15);
	addressText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Trade ID:"));
		first.add(tridText);
		first.add(new Label("Administrator:"));
		first.add(administratorText);
		first.add(new Label("Contact:"));
		first.add(contactText);
		first.add(new Label("Currency to:"));
		first.add(currencytoText);
		first.add(new Label("Address:"));
		first.add(addressText);
		
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteTradeButton);
		
		Panel third = new Panel();
		third.add(errorText);
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove Trade");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteTrade dtrade = new DeleteTrade();

		dtrade.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		dtrade.buildGUI();
	}
}
