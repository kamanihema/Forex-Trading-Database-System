import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteTransaction extends Frame 
{
	Button deleteTransactionButton;
	List TransactionIDList;
	TextField tidText, currencyofText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteTransaction() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hema","vasavi");
		  statement = connection.createStatement();

		}  
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadTransaction() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM transaction");
		  while (rs.next()) 
		  {
			TransactionIDList.add(rs.getString("TID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    TransactionIDList = new List(10);
		loadTransaction();
		add(TransactionIDList);
		
		//When a list item is selected populate the text fields
	TransactionIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM TRANSACTION");
					while (rs.next()) 
					{
						if (rs.getString("TID").equals(TransactionIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						tidText.setText(rs.getString("TID"));
						currencyofText.setText(rs.getString("CURRENCYOF"));
						//passwordText.setText(rs.getString("password"));
						//cusnameText.setText(rs.getString("customer name"));
					//	passwordText.setText(rs.getString("password"));
						//contactText.setText(rs.getString("contact"));
					//	addressText.setText(rs.getString("Address"));
					
					
					
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		deleteTransactionButton = new Button("Delete Transaction");
		deleteTransactionButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM Transaction WHERE TID = '"
							+ TransactionIDList.getSelectedItem()+"' and  currencyof='"+ currencyofText.getText()+"'");
					errorText.append("\nDeleted " + i + " rows successfully");
					tidText.setText(null);
					currencyofText.setText(null);
					//passwordText.setText(null);
				//	cusnameText.setText(null);
				//	contactText.setText(null);	addressText.setText(null);
					
					TransactionIDList.removeAll();
					loadTransaction();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		tidText = new TextField(15);
		currencyofText = new TextField(15);
		//passwordText = new TextField(15);
	//cusnameText = new TextField(15);
//	contactText = new TextField(15);
	//addressText = new TextField(15);
	

	

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label(" Trade ID:"));
		first.add(tidText);
		first.add(new Label("curency of:"));
		first.add(currencyofText);
		//first.add(new Label("Password:"));
	//	first.add(passwordText);
	//	first.add(new Label("Customer name:"));
		//first.add(cusnameText);
		//cusnameText = new TextField(15);
		//first.add(new Label("contact:"));
		//first.add(contactText);
		//first.add(new Label("address:"));
		//first.add(addressText);
		

		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteTransactionButton);
		
		Panel third = new Panel();
		third.add(errorText);
		add(first);
		add(second);
		add(third);
	    
		setTitle("Transaction");
		setSize(600, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteTransaction dTransaction = new DeleteTransaction();

		dTransaction.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		dTransaction.buildGUI();
	}
}
