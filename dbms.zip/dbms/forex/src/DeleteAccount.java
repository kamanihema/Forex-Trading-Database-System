import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteAccount extends Frame 
{
	Button deleteAccountButton;
	List AccountIDList;
	TextField aidText, acctypeText, balanceText, balancetypeText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteAccount() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hema","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadAccounts() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM ACCOUNT");
		  while (rs.next()) 
		  {
			AccountIDList.add(rs.getString("ACCOUNTID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    AccountIDList = new List(10);
		loadAccounts();
		add(AccountIDList);
		
		//When a list item is selected populate the text fields
		AccountIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM account");
					while (rs.next()) 
					{
						if (rs.getString("ACCOUNTID").equals(AccountIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						aidText.setText(rs.getString("ACCOUNTID"));
						acctypeText.setText(rs.getString("ACCOUNTTYPE"));
						balanceText.setText(rs.getString("BALANCE"));
						balancetypeText.setText(rs.getString("BALANCETYPE"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		deleteAccountButton = new Button("Delete Acccount");
		deleteAccountButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM account WHERE ACCOUNTID = '"
							+ AccountIDList.getSelectedItem()+"' and accounttype='"+ acctypeText.getText()+"' and balance='"+balanceText.getText()+"' and balancetype='"+ balancetypeText.getText()+"'"); 
					//errorText.append("\nDeleted "+i+ "rows successfully"););
					errorText.append("\nDeleted " + i + " rows successfully");
					aidText.setText(null);
					acctypeText.setText(null);
					balanceText.setText(null);
					balancetypeText.setText(null);
					AccountIDList.removeAll();
					loadAccounts();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		aidText = new TextField(15);
		acctypeText = new TextField(15);
		balanceText = new TextField(15);
	balancetypeText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Account ID:"));
		first.add(aidText);
		first.add(new Label("Account TYpe:"));
		first.add(acctypeText);
		first.add(new Label("Balance:"));
		first.add(balanceText);
		first.add(new Label("Balance TYpe:"));
		first.add(balancetypeText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteAccountButton);
		
		Panel third = new Panel();
		third.add(errorText);
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove Account");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteAccount dels = new DeleteAccount();

		dels.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		dels.buildGUI();
	}
}
