import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateAccount extends Frame 
{
	Button updateAccountButton;
	List accountIDList;
	TextField aidText, acctypeText, balanceText, balancetypeText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateAccount() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hema","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadAccount() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT  ACCOUNTID FROM ACCOUNT");
		  while (rs.next()) 
		  {
			accountIDList.add(rs.getString("ACCOUNTID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    accountIDList = new List(10);
		loadAccount();
		add(accountIDList);
		
		//When a list item is selected populate the text fields
		accountIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM ACCOUNT WHERE ACCOUNTID ='"+accountIDList.getSelectedItem()+"'");
					rs.next();
					aidText.setText(rs.getString("ACCOUNTID"));
					acctypeText.setText(rs.getString(" accounttype"));
					balanceText.setText(rs.getString("balance"));
					balancetypeText.setText(rs.getString("balancetype"));
					
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updateAccountButton = new Button("Update Account");
		updateAccountButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE account "
					+ "SET accounttype='" + acctypeText.getText() + "', "
					+ "balance='" + balanceText.getText() + "', "
					+ "balancetype ='"+ balancetypeText.getText() + " ' WHERE accountid =' "
					+ accountIDList.getSelectedItem()+"'");
					errorText.append("\nUpdated " + i + " rows successfully");
					accountIDList.removeAll();
					loadAccount();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		aidText = new TextField(15);
		aidText.setEditable(false);
		acctypeText = new TextField(15);
		balanceText = new TextField(15);
		balancetypeText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Account Id:"));
		first.add(aidText);
		first.add(new Label("Account Type:"));
		first.add(acctypeText);
		first.add(new Label("Balance:"));
		first.add(balanceText);
		first.add(new Label("Balance Type:"));
		first.add(balancetypeText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateAccountButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update Account");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateAccount ups = new UpdateAccount();

		ups.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		ups.buildGUI();
	}
}
