import java.awt.*; 
import java.awt.event.*; 

class ForexTrading extends Frame implements ActionListener
{ 
	  String msg = ""; 
	  Label ll;
	  InsertAccount sail;
	  UpdateAccount ups;
	  DeleteAccount dels;
	  UpdateAccount upb;
	  InsertLogin ilogin;
	  DeleteLogin dlogin;
	  UpdateLogin ulogin;
	  InsertTransaction iTransaction;
	  UpdateTransaction  uTransaction;
	  DeleteTransaction  dTransaction;
	  InsertTrade iTrade;
	  UpdateTrade uTrade;
	  DeleteTrade dTrade;
	  
	  
	  
	 // MakeReservation mks;
	  
	  ForexTrading() 
	  { 
			ll = new Label();
			ll.setAlignment(Label.CENTER);  
			ll.setBounds(90,250,250,100); 			
			ll.setText("Welcome to  Forex Trading");
			add(ll);
		 
			// create menu bar and add it to frame 
			MenuBar mbar = new MenuBar(); 
			setMenuBar(mbar); 
		 
			// create the menu items and add it to Menu
			Menu sailor = new Menu("Account"); 
			MenuItem item1, item2, item3; 
			sailor.add(item1 = new MenuItem("Insert ")); 
			sailor.add(item2 = new MenuItem("View Account")); 
			sailor.add(item3 = new MenuItem("Delete Account")); 
			mbar.add(sailor);  
		 
			Menu boat = new Menu("Login"); 
			MenuItem item4, item5, item6; 
			boat.add(item4 = new MenuItem("Insert Login")); 
			boat.add(item5 = new MenuItem("View Login")); 
			boat.add(item6 = new MenuItem("Delete Login"));  
			mbar.add(boat); 
			Menu trans = new Menu("Transaction"); 
			MenuItem item7, item8, item9; 
			boat.add(item7 = new MenuItem("Insert Transaction")); 
			boat.add(item8 = new MenuItem("View Transaction")); 
			boat.add(item9 = new MenuItem("Delete Transaction"));  
			mbar.add(trans); 
			Menu trade = new Menu("Trade"); 
			MenuItem item10, item11, item12; 
			boat.add(item10 = new MenuItem("Insert Trade")); 
			boat.add(item11 = new MenuItem("View Trade")); 
			boat.add(item12 = new MenuItem("Delete Trade"));  
			mbar.add(trade); 
			Menu reserve = new Menu("Reservations"); 
			MenuItem item13, item14, item15; 
			reserve.add(item13 = new MenuItem("Make Reservation")); 
			reserve.add(item14= new MenuItem("View Reservation")); 
			reserve.add(item15= new MenuItem("Delete Reservation")); 
			mbar.add(reserve); 
			
			
			
			// register listeners
			item1.addActionListener(this); 
			item2.addActionListener(this); 
			item3.addActionListener(this); 
			item4.addActionListener(this); 
			item5.addActionListener(this); 
			item6.addActionListener(this); 
			item7.addActionListener(this); 
			item8.addActionListener(this); 
			item9.addActionListener(this); 
			item10.addActionListener(this); 
			item11.addActionListener(this); 
			item12.addActionListener(this); 
			item13.addActionListener(this); 
			item14.addActionListener(this); 
			item15.addActionListener(this); 
			 // Anonymous inner class which extends WindowAdaptor to handle the Window event: windowClosing  
			addWindowListener(new WindowAdapter(){
				public void windowClosing(WindowEvent we) 
				{ 
					System.exit(0);	
				} 
			}); 
			
			//Frame properties
			setTitle("Forex Trading DataBase System "); 
			Color clr = new Color(200, 100, 150);
			setBackground(clr); 
			setFont(new Font("SansSerif", Font.BOLD, 14)); 
			setLayout(null);
			setSize(500, 600); 
			setVisible(true);	
			
	  }   
	  
	  public void actionPerformed(ActionEvent ae) 
	  { 

		  String arg = ae.getActionCommand(); 
		  if(arg.equals("Insert Acount"))
		  {
			sail = new InsertAccount();

			sail.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				sail.dispose();
			}
			});		
			sail.buildGUI();	
          }			
		 
		 else if(arg.equals("View Account")) 
		 {
			ups = new UpdateAccount();
			ups.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				ups.dispose();
			}
			});		
			ups.buildGUI();		 
		 }
		 
		 else if(arg.equals("Delete Account")) 
		 {
			dels = new DeleteAccount();

			dels.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				dels.dispose();
			}
			});		
			dels.buildGUI();		 
		 }
		 
		 else if(arg.equals("View Login")) 
		 {
			ulogin = new UpdateLogin();
			upb.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				upb.dispose();
			}
			});		
			upb.buildGUI();		 
		 }
		 else if(arg.equals("Delete Login")) 
		 {
			dlogin = new DeleteLogin();

			dlogin.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				dlogin.dispose();
			}
			});		
			dlogin.buildGUI();	
		 }
		 else if(arg.equals("Insert Login")) 
		 {
			ilogin = new InsertLogin();

			ilogin.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				ilogin.dispose();
			}
			});		
			ilogin.buildGUI();	
		 }
		 else if(arg.equals("Insert Transaction"))
		  {
			iTransaction = new InsertTransaction();

			iTransaction.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				iTransaction.dispose();
			}
			});		
			iTransaction.buildGUI();	
          }			
		 
		 else if(arg.equals("View Transaction")) 
		 {
			uTransaction = new UpdateTransaction();
			uTransaction.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				uTransaction.dispose();
			}
			});		
			uTransaction.buildGUI();		 
		 }
		 
		 else if(arg.equals("Delete Transaction")) 
		 {
			dTransaction = new DeleteTransaction();

			dTransaction.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				dTransaction.dispose();
			}
			});		
			dTransaction.buildGUI();		 
		 }
		 else if(arg.equals("Insert Trade"))
		  {
			iTrade = new InsertTrade();

			iTrade.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				iTrade.dispose();
			}
			});		
			iTrade.buildGUI();	
         }			
		 
		 else if(arg.equals("View Trade")) 
		 {
			uTrade = new UpdateTrade();
			uTrade.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
		    {
				uTrade.dispose();
			}
			});		
			uTrade.buildGUI();		 
		 }
		 
		 else if(arg.equals("Delete Trade")) 
		 {
			dTrade = new DeleteTrade();

			dTrade.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e) 
			{
				dTrade.dispose();
			}
			});		
			dTrade.buildGUI();		 
		 }


		// else if(arg.equals("Make Reservation")) 
		// {
			//mks = new MakeReservation();
			//setVisible(false); 
		//	mks.addWindowListener(new WindowAdapter(){
		//	public void windowClosing(WindowEvent e) 
			//{
				//mks.dispose();
			//	setVisible(true);
			//}
			//});		
			//mks.buildGUI();		 
		 //}			 
	  }
	  public static void main(String ... args)
	  {
			new ForexTrading();	  
	  }
} 
 

 
