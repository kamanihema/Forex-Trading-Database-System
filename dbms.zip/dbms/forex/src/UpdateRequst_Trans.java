import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateRequst_Trans extends Frame 
{
	Button updateButton;
	List accountIDList;
	TextField onthedaytext,cidtext,tidtext;
	Choice cidSelect, tidSelect;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateRequst_Trans() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hema","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	
	private void loadLogin() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM login");
		  while (rs.next()) 
		  {
			cidSelect.add(rs.getString("customerid"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	private void loadTransaction() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM transaction");
		  while (rs.next()) 
		  {
		tidSelect.add(rs.getString("TID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	public void buildGUI() 
	{		
	    accountIDList = new List(10);
		loadAccount();
		add(accountIDList);
		
		//When a list item is selected populate the text fields
		accountIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM requst_transaction WHERE ACCOUNTID ='"+accountIDList.getSelectedItem()+"'");
					rs.next();
					aidtext.setText(rs.getString("ACCOUNTID"));
					cidtext.setText(rs.getString("tid"));
					//balanceText.setText(rs.getString("balance"));
				//	balancetypeText.setText(rs.getString("balancetype"));
					
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updateCustomerAccountButton = new Button("Update Account");
		updateCustomerAccountButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE requst_transaction "
					+ "SET ontheday='" + aidText.getText() + "'+"' WHERE accountid =' "
					+ accountIDList.getSelectedItem()+"'");
					errorText.append("\nUpdated " + i + " rows successfully");
					accountIDList.removeAll();
					loadAccount();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		aidText = new TextField(15);
		aidText.setEditable(false);
		acctypeText = new TextField(15);
		balanceText = new TextField(15);
		balancetypeText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Account Id:"));
		first.add(aidText);
		first.add(new Label("Customer Id:"));
		first.add(cidText);
		first.add(new Label("On the day"));
	first.add(onthedayText);
		//first.add(new Label("Balance Type:"));
	//	first.add(balancetypeText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateAccountButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update Account");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateRequst_Trans ups = new UpdateRequst_Trans();

		ups.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		ups.buildGUI();
	}
}
