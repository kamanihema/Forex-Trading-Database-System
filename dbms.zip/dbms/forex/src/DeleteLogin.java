import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteLogin extends Frame 
{
	Button deleteLoginButton;
	List LoginIDList;
	TextField cidText, unameText, contactText, addressText,cusnameText,passwordText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteLogin() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hema","vasavi");
		  statement = connection.createStatement();

		}  
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadLogin() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM LOGIN");
		  while (rs.next()) 
		  {
			LoginIDList.add(rs.getString("CUSTOMERID"));
		  }
		} 
		catch (SQLException e)
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    LoginIDList = new List(10);
		loadLogin();
		add(LoginIDList);
		
		//When a list item is selected populate the text fields
		LoginIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Login");
					while (rs.next()) 
					{
						if (rs.getString("CUSTOMERID").equals(LoginIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						cidText.setText(rs.getString("CUSTOMERID"));
						unameText.setText(rs.getString("username"));
						passwordText.setText(rs.getString("password"));
						cusnameText.setText(rs.getString("customername"));
						//passwordText.setText(rs.getString("password"));
						contactText.setText(rs.getString("contact"));
						addressText.setText(rs.getString("Address"));
					
					
					
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		deleteLoginButton = new Button("Delete Login");
		deleteLoginButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM login WHERE customerID = "
							+ LoginIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					cidText.setText(null);
					unameText.setText(null);
					passwordText.setText(null);
					cusnameText.setText(null);
					contactText.setText(null);	addressText.setText(null);
					
					LoginIDList.removeAll();
					loadLogin();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		cidText = new TextField(15);
		unameText = new TextField(15);
		passwordText = new TextField(15);
	cusnameText = new TextField(15);
	contactText = new TextField(15);
	addressText = new TextField(15);
	

	

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Customer ID:"));
		first.add(cidText);
		first.add(new Label("User name TYpe:"));
		first.add(unameText);
		first.add(new Label("Password:"));
		first.add(passwordText);
		first.add(new Label("Customer name:"));
		first.add(cusnameText);
		//cusnameText = new TextField(15);
		first.add(new Label("contact:"));
		first.add(contactText);
		first.add(new Label("address:"));
		first.add(addressText);
		

		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteLoginButton);
		
		Panel third = new Panel();
		third.add(errorText);
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove Login");
		setSize(600, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteLogin dlogin = new DeleteLogin();

		dlogin.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		dlogin.buildGUI();
	}
}
