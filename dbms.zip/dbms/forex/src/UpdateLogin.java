import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateLogin extends Frame 
{
	Button updateLoginButton;
	List updateIDList;
	TextField cidText, unameText, passwordText,cusnameText,addressText,contactText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateLogin() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hema","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadLogin() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT customerid FROM login");
		  while (rs.next()) 
		  {
			updateIDList.add(rs.getString("CUSTOMERID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    updateIDList = new List(6);
		loadLogin();
		add(updateIDList);
		
		//When a list item is selected populate the text fields
	updateIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
				//rs = statement.executeQuery("SELECT * FROM login where");
					//='"+TradeIDList.getSelectedItem()+"'");
							rs = statement.executeQuery("SELECT * FROM login where customerid ='"+updateIDList.getSelectedItem()+"'");

					while (rs.next()) 
					{
						if (rs.getString("CUSTOMERID").equals(updateIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						cidText.setText(rs.getString("CUSTOMERID"));
						unameText.setText(rs.getString("USERNAME"));
						passwordText.setText(rs.getString("password"));
						cusnameText.setText(rs.getString("customername"));
						contactText.setText(rs.getString("contact"));
				addressText.setText(rs.getString("address"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updateLoginButton = new Button("Update Login");
		updateLoginButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE login "
					+ "SET username='" + unameText.getText() + "', "
					+ "password='" + passwordText.getText() + "',"
					+  "customername='" + cusnameText.getText() + "',"
							+ "contact='" + contactText.getText() + "',"
							+ "address='" + addressText.getText() + " 'WHERE customerid = '" + updateIDList.getSelectedItem()+"'");
			
					errorText.append("\nUpdated " + i + " rows successfully");
					updateIDList.removeAll();
					loadLogin();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		cidText = new TextField(15);
		cidText.setEditable(false);
		unameText = new TextField(15);
		passwordText = new TextField(15);
		cusnameText = new TextField(15);
		
		contactText = new TextField(15);
		addressText = new TextField(15);
		
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Customer ID:"));
		first.add(cidText);
		first.add(new Label("User Name:"));
		first.add(unameText);
		first.add(new Label("Password:"));
		first.add(passwordText);
		first.add(new Label("Customer Name:"));
		first.add(cusnameText);
		first.add(new Label("Contact:"));
		first.add(contactText);
		first.add(new Label("Address:"));
		first.add(addressText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateLoginButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update Login");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateLogin ulogin = new UpdateLogin();

		ulogin.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		ulogin.buildGUI();
	}
}
