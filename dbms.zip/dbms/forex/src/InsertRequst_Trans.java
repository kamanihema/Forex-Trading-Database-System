import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertRequst_Trans extends Frame 
{
	Button reqtransButton;
	TextField onthedayText;
	Choice tidSelect, aidSelect;
	//,sinceText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public InsertRequst_Trans() 
	{
 		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hema","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadAccount() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM account");
		  while (rs.next()) 
		  {
			aidSelect.add(rs.getString("accountid"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	private void loadTransaction() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM transaction");
		  while (rs.next()) 
		  {
			tidSelect.add(rs.getString("tid"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	public void buildGUI() 
	{		
	   aidSelect = new Choice();
		loadAccount();
		
		tidSelect = new Choice();
		loadTransaction();
		
	    
		//Handle Reserve Button
		reqtransButton = new Button("Request Transaction ");
		reqtransButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  Statement statement = connection.createStatement();
				  //String query = "INSERT INTO reserves VALUES (71,101,'12-NOV-13')";				  
				  String query= "INSERT INTO requst_transaction VALUES(" + "'" + aidSelect.getSelectedItem() +  "','" + tidSelect.getSelectedItem()  +"','"+ onthedayText.getText() +  "','"  +")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

		
		onthedayText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(3, 2));
		first.add(new Label("Account ID:"));
		first.add(aidSelect);
		first.add(new Label("Transaction ID:"));
		first.add(tidSelect);
		first.add(new Label("On The day:"));
		first.add(onthedayText);

		
		Panel second = new Panel(new GridLayout(1, 1));
		second.add(reqtransButton);
		
		Panel third = new Panel();
		third.add(errorText);			

		add(first);
		add(second);
		add(third);
	    
		setTitle("Make Requst_Transaction");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertRequst_Trans ireq = new InsertRequst_Trans();

		ireq.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		ireq.buildGUI();
	}
}
