import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteRequst_Trans extends Frame 
{
	Button deleteCustomerButton;
	List Requst_TransList;
	TextField onthedaytext,tidtext,aidtext;
	//Choice cidSelect, aidSelect;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteRequst_Trans() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hema","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadRequst_Trans() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Requst_Transaction");
		  while (rs.next()) 
		  {
			  Requst_TransList.add(rs.getString("cid") + " " + rs.getString("accountid"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	
	
	public void buildGUI() 
	{		

		  Requst_TransList = new List(10);
		loadRequst_Trans();
		//loadAccount();
		add(Requst_TransList);
		
		//When a list item is selected populate the text fields
		Requst_TransList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM customer_account");
					while (rs.next()) 
					{
						if (rs.getString("AccountID").equals(Requst_TransList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						aidtext.setText(rs.getString("AccountID"));
						tidtext.setText(rs.getString("TID"));
						onthedaytext.setText(rs.getString("Ontheday"));
						//balancetypeText.setText(rs.getString("Balance Type"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Delete Sailor Button
		deleteCustomerButton = new Button("Delete Customer_Acccount");
		deleteCustomerButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM requst_transaction WHERE aID = "
							+ Requst_TransList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					tidtext.setText(null);
					aidtext.setText(null);
					//balanceText.setText(null);
					//balancetypeText.setText(null);
					Requst_TransList.removeAll();
					loadRequst_Trans();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		aidtext = new TextField(15);
		cidtext = new TextField(15);
		sinceText = new TextField(15);
	//balancetypeText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Account ID:"));
		first.add(aidtext);
		first.add(new Label("Customer ID:"));
		first.add(cidtext);
		first.add(new Label("Since:"));
		first.add(sinceText);
		//first.add(new Label("Balance TYpe:"));
		//first.add(balancetypeText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteCustomerButton);
		
		Panel third = new Panel();
		third.add(errorText);
		add(first);
		add(second);
		add(third);
	    
		setTitle("Remove Account");
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteAccount dels = new DeleteAccount();

		dels.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		dels.buildGUI();
	}
}
