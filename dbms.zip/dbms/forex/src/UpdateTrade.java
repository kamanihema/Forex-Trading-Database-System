import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateTrade extends Frame 
{
	Button updateTradeButton;
	List TradeIDList;
	TextField tridText, administratorText,contactText, currencyToText,addressText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateTrade() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hema","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadTrade() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT TRID FROM TRADE");
		  while (rs.next()) 
		  {
			TradeIDList.add(rs.getString("TRID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    TradeIDList = new List(10);
		loadTrade();
		add(TradeIDList);
		
		//When a list item is selected populate the text fields
		TradeIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM TRADE where TRID ='"+TradeIDList.getSelectedItem()+"'");
					rs.next();
					tridText.setText(rs.getString("TRID"));
					administratorText.setText(rs.getString("ADMINISTRATOR"));
					contactText.setText(rs.getString("CONTACT"));
					currencyToText.setText(rs.getString("CURRENCYTO"));
					addressText.setText(rs.getString("ADDRESS"));
					

					
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button+"'");

		updateTradeButton = new Button("Update Trade");
		updateTradeButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE TRADE "
					+ "SET administrator='" + administratorText.getText() +"', "
							+ "contact='" + contactText.getText() + "', " +
					 "currencyto ='" + currencyToText.getText() +"'," 
							+ "address='" + addressText.getText() + 
							"'where trid='" + TradeIDList.getSelectedItem()+"'");
								
						




					errorText.append("\nUpdated " + i + " rows successfully");
					TradeIDList.removeAll();
					loadTrade();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		tridText = new TextField(15);
		tridText.setEditable(false);
		administratorText = new TextField(15);
		contactText = new TextField(15);
		currencyToText = new TextField(15);
		addressText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Trade Id:"));
		first.add(tridText);
		first.add(new Label("administrator:"));
		first.add(administratorText);
		first.add(new Label("Contact:"));
		first.add(contactText);
		first.add(new Label("currency to:"));
		first.add(currencyToText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateTradeButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setTitle("Update Trade");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateTrade uTrade = new UpdateTrade();

		uTrade.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		uTrade.buildGUI();
	}
}
