import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertCustomerAccount extends Frame 
{
	Button cusaccountButton;
	TextField sinceText;
	Choice cidSelect, aidSelect;
	//,sinceText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public InsertCustomerAccount() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hema","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadLogin() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM login");
		  while (rs.next()) 
		  {
			cidSelect.add(rs.getString("customerid"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	private void loadAccount() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM account");
		  while (rs.next()) 
		  {
			aidSelect.add(rs.getString("accountid"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	public void buildGUI() 
	{		
	    cidSelect = new Choice();
		loadLogin();
		
		aidSelect = new Choice();
		loadAccount();
		
	    
		//Handle Reserve Button
		cusaccountButton = new Button("Customer Account ");
		cusaccountButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  Statement statement = connection.createStatement();
				  //String query = "INSERT INTO reserves VALUES (71,101,'12-NOV-13')";				  
				  String query= "INSERT INTO customer_account VALUES(" +"'"+ cidSelect.getSelectedItem() + "','" + aidSelect.getSelectedItem() + "','" + sinceText.getText() + "'" +")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

		
		sinceText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(3, 2));
		first.add(new Label("Customer ID:"));
		first.add(cidSelect);
		first.add(new Label("Account ID:"));
		first.add(aidSelect);
		first.add(new Label("Since:"));
		first.add(sinceText);

		
		Panel second = new Panel(new GridLayout(1, 1));
		second.add(cusaccountButton);
		
		Panel third = new Panel();
		third.add(errorText);			

		add(first);
		add(second);
		add(third);
	    
		setTitle("Make Customer_Account");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertCustomerAccount icus = new InsertCustomerAccount();

		icus.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		icus.buildGUI();
	}
}
