import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertTrading extends Frame 
{
	Button tradingButton;
	//TextField onthedayText;
	Choice tidSelect, tridSelect;
	//,sinceText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public InsertTrading() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hema","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadTrade() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM does_Trading");
		  while (rs.next()) 
		  {
			tridSelect.add(rs.getString("TRID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	private void loadTransaction() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM transaction");
		  while (rs.next()) 
		  {
			tidSelect.add(rs.getString("Transaction ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	public void buildGUI() 
	{		
	    tridSelect = new Choice();
		loadTrade();
		
		tidSelect = new Choice();
		loadTransaction();
		
	    
		//Handle Reserve Button
		tradingButton = new Button("Does Trading ");
		tradingButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  Statement statement = connection.createStatement();
				  //String query = "INSERT INTO reserves VALUES (71,101,'12-NOV-13')";				  
				  String query= "INSERT INTO does_trading VALUES("  + "'"+tridSelect.getSelectedItem() +   "','"+ tidSelect.getSelectedItem() +  "'" +")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

		
		//onthedayText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(3, 2));
		first.add(new Label("TRID:"));
		first.add(tridSelect);
		first.add(new Label("Transaction ID:"));
		first.add(tidSelect);
		//first.add(new Label("On The day:"));
	//	first.add(onthedayText);

		
		Panel second = new Panel(new GridLayout(1, 1));
		second.add(tradingButton);
		
		Panel third = new Panel();
		third.add(errorText);			

		add(first);
		add(second);
		add(third);
	    
		setTitle("Does Trading");
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}	

	private void displaySQLErrors(SQLException e)
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertTrading itrading = new InsertTrading();

		itrading.addWindowListener(new WindowAdapter(){
		  public void windowClosing(WindowEvent e) 
		  {
			System.exit(0);
		  }
		});
		
		itrading.buildGUI();
	}
}
